Para jugar Tochino, es necesario tener un dispositivo compatible con Swift, ya sea un iPad o Mac.

En iPad, se necesita tener descargada la aplicación de Swift Playgrounds, y para Mac se necesita Xcode.