import SwiftUI
import AVFoundation

struct RouletteGameView: View {
    @EnvironmentObject var gameState: GameState
    
    @State private var chipAudio: AVAudioPlayer?
    @State private var spinAudio: AVAudioPlayer?
    @State private var winAudio: AVAudioPlayer?
    
    @State private var betGreen = true
    @State private var betRed = false
    @State private var betBlue = false
    @State private var betYellow = false
    @State private var betWhite = false
    @State private var betBlack = false
    @State private var oddBet = false
    @State private var blackBet = false
    @State private var whiteBet = false
    @State private var evenBet = false
    @State private var to2536Bet = false
    @State private var to1324Bet = false
    @State private var to0112Bet = false
    @State private var top2to1Bet = false
    @State private var mid2to1Bet = false
    @State private var bot2to1Bet = false
    @State private var numberBet = Array(repeating: false, count: 36)
    @State private var s0Bet = false
    @State private var s00Bet = false
    @State private var to1936Bet = false
    @State private var to0118Bet = false
    @State private var oddChip = 0
    @State private var blackChip = 0
    @State private var whiteChip = 0
    @State private var evenChip = 0
    @State private var to2536Chip = 0
    @State private var to1324Chip = 0
    @State private var to0112Chip = 0
    @State private var top2to1Chip = 0
    @State private var mid2to1Chip = 0
    @State private var bot2to1Chip = 0
    @State private var numberChip = Array(repeating: 0, count: 36)
    @State private var s0Chip = 0
    @State private var s00Chip = 0
    @State private var to1936Chip = 0
    @State private var to0118Chip = 0
    @State private var rouletteSpinning = false
    @State private var ballPosition = CGSize(width: 86.01, height: 93.44)
    @State private var ballPositionAngleDeg = 47.3684
    @State private var animationTimer: Timer?
    @State private var chipsPlaced = 0
    @State private var currentBallNumber = 8
    @State private var currentNumberIndex = 0
    
    let ballPathRadius = 127.0
    let totalNumbers = 38
    let wheelNumbers = [8, 12, 29, 25, 10, 27, 100, 1, 13, 36, 24, 3, 15, 34, 22, 5, 17, 32, 20, 7, 11, 30, 26, 9, 28, 0, 2, 14, 35, 23, 4, 16, 33, 21, 6, 18, 31, 19]
    let isBlackNumber = [true, false, true, false, true, false, true, false, true, false, false, true, false, true, false, true, false, true, true, false, true, false, true, false, true, false, true, false, false, true, false, true, false, true, false, true]
    
    func initializeSounds() {
        guard let url = Bundle.main.url(forResource: "Roulette Spin SFX", withExtension: "mp3") else {
            return
        }
        
        spinAudio = try? AVAudioPlayer(contentsOf: url)
        
        guard let url = Bundle.main.url(forResource: "Roulette Win SFX", withExtension: "mp3") else {
            return
        }
        
        winAudio = try? AVAudioPlayer(contentsOf: url)
    }
    
    func chooseChip(from chipValue: Int) {
        betGreen = false
        betRed = false
        betBlue = false
        betYellow = false
        betWhite = false
        betBlack = false
        
        switch chipValue {
        case 1:
            betGreen = true
            break
        case 5:
            betRed = true
            break
        case 25:
            betBlue = true
            break
        case 100:
            betYellow = true
            break
        case 500:
            betWhite = true
            break
        case 5000:
            betBlack = true
            break
        default:
            break
        }
    }
    
    func checkChip() -> Int {
        if (betGreen) {
            return 1
        }
        if (betRed) {
            return 5
        }
        if (betBlue) {
            return 25
        }
        if (betYellow) {
            return 100
        }
        if (betWhite) {
            return 500
        }
        if (betBlack) {
            return 5000
        }
        
        return 0
    }
    
    func spinRoulette() {
        spinAudio?.play()
        rouletteSpinning = true
        
        let randomNumber = Int.random(in: 0...37)
        
        animationTimer?.invalidate()
        
        let degreesPerNumber = 360.0 / Double(totalNumbers)
        
        var frameCount = 0
        animationTimer = Timer.scheduledTimer(withTimeInterval: 0.025, repeats: true) { timer in
            frameCount += 1
            
            ballPositionAngleDeg -= degreesPerNumber
            
            if ballPositionAngleDeg < 0.0 {
                ballPositionAngleDeg += 360.0
            }
            
            let radians = ballPositionAngleDeg * .pi / 180.0
            ballPosition = CGSize(
                width: ballPathRadius * cos(radians),
                height: ballPathRadius * sin(radians)
            )
            
            if frameCount > 75 + randomNumber {
                spinAudio?.stop()
                spinAudio?.currentTime = 0
                timer.invalidate()
                rouletteSpinning = false
                calculateBallLandingNumber(from: randomNumber)
                calculateWinnings()
                resetTable()
            }
        }
    }
    
    func calculateBallLandingNumber(from numbersAdvanced: Int) {
        currentNumberIndex += numbersAdvanced
        currentNumberIndex %= 38
        currentBallNumber = wheelNumbers[currentNumberIndex]
    }
    
    func calculateWinnings () {
        var wonMoney = false
        
        switch currentBallNumber {
        case 0:
            if s0Bet {
                wonMoney = true
                gameState.money += (s0Chip * 36)
            }
            break
        case 1...36:
            if numberBet[currentBallNumber - 1] {
                wonMoney = true
                gameState.money += (numberChip[currentBallNumber - 1] * 36)
            }
            
            if (top2to1Bet && (currentBallNumber % 3) == 1) {
                wonMoney = true
                gameState.money += (top2to1Chip * 3)
            }
            if (mid2to1Bet && (currentBallNumber % 3) == 2) {
                wonMoney = true
                gameState.money += (mid2to1Chip * 3)
            }
            if (bot2to1Bet && (currentBallNumber % 3) == 0) {
                wonMoney = true
                gameState.money += (bot2to1Chip * 3)
            }
            
            if (to0112Bet && (currentBallNumber >= 1) && (currentBallNumber <= 12)) {
                wonMoney = true
                gameState.money += (to0112Chip * 3)
            }
            if (to1324Bet && (currentBallNumber >= 13) && (currentBallNumber <= 24)) {
                wonMoney = true
                gameState.money += (to1324Chip * 3)
            }
            if (to2536Bet && (currentBallNumber >= 25) && (currentBallNumber <= 36)) {
                wonMoney = true
                gameState.money += (to2536Chip * 3)
            }
            
            if (to0118Bet && (currentBallNumber >= 1) && (currentBallNumber <= 18)) {
                wonMoney = true
                gameState.money += (to0118Chip * 2)
            }
            if (to1936Bet && (currentBallNumber >= 19) && (currentBallNumber <= 36)) {
                wonMoney = true
                gameState.money += (to1936Chip * 2)
            }
            
            if (oddBet && ((currentBallNumber % 2) == 1)) {
                wonMoney = true
                gameState.money += (oddChip * 2)
            }
            if (evenBet && ((currentBallNumber % 2) == 0)) {
                wonMoney = true
                gameState.money += (evenChip * 2)
            }
            
            if (blackBet && isBlackNumber[currentBallNumber - 1]) {
                wonMoney = true
                gameState.money += (blackChip * 2)
            }
            if (whiteBet && !isBlackNumber[currentBallNumber - 1]) {
                wonMoney = true
                gameState.money += (whiteChip * 2)
            }
            
            break
        case 100:
            if s00Bet {
                wonMoney = true
                gameState.money += (s0Chip * 36)
            }
            break
        default:
            break
        }
        
        if wonMoney {
            winAudio?.play()
        }
    }
    
    func resetTable() {
        oddBet = false
        evenBet = false
        to0112Bet = false
        to1324Bet = false
        to2536Bet = false
        blackBet = false
        whiteBet = false
        top2to1Bet = false
        mid2to1Bet = false
        bot2to1Bet = false
        to0118Bet = false
        to1936Bet = false
        s0Bet = false
        s00Bet = false
        
        for i in 0...35 {
            numberBet[i] = false
            numberChip[i] = 0
        }
        
        oddChip = 0
        evenChip = 0
        to0112Chip = 0
        to1324Chip = 0
        to2536Chip = 0
        blackChip = 0
        whiteChip = 0
        top2to1Chip = 0
        mid2to1Chip = 0
        bot2to1Chip = 0
        to0118Chip = 0
        to1936Chip = 0
        s0Chip = 0
        s00Chip = 0
        
        chipsPlaced = 0
    }
    
    func playChipSound() {
        guard let url = Bundle.main.url(forResource: "Bet Chip SFX", withExtension: "mp3") else {
            return
        }
        
        chipAudio = try? AVAudioPlayer(contentsOf: url)
        chipAudio?.play()
    }
    
    var body: some View {
        GeometryReader { geometry in
            let isLandscape = geometry.size.width > geometry.size.height
            
            ZStack {
                Image("Roulette Cloth")
                    .resizable()
                    .scaledToFill()
                
                VStack {
                    Text("$\(gameState.money)")
                        .foregroundColor(.black)
                        .font(.system(.title, design: .rounded)).bold()
                        .padding(10)
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .padding(.bottom, 10)
                    
                    if isLandscape {
                        HStack {
                            rouletteWheelView()
                            
                            rouletteBoardView()
                        }
                    } else {
                        VStack {
                            rouletteWheelView()
                            
                            rouletteBoardView()
                        }
                    }
                    
                    HStack {
                        Button {
                            chooseChip(from: 1)
                        } label: {
                            Image("Chip 1")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: (betGreen ? 120 : 100))
                        }
                        
                        Button {
                            chooseChip(from: 5)
                        } label: {
                            Image("Chip 5")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: (betRed ? 120 : 100))
                        }
                        
                        Button {
                            chooseChip(from: 25)
                        } label: {
                            Image("Chip 25")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: (betBlue ? 120 : 100))
                        }
                        
                        Button {
                            chooseChip(from: 100)
                        } label: {
                            Image("Chip 100")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: (betYellow ? 120 : 100))
                        }
                        
                        Button {
                            chooseChip(from: 500)
                        } label: {
                            Image("Chip 500")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: (betWhite ? 120 : 100))
                        }
                        
                        Button {
                            chooseChip(from: 5000)
                        } label: {
                            Image("Chip 5000")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: (betBlack ? 120 : 100))
                        }
                    }
                    
                    Text("\n")
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .onDisappear() {
                chipAudio?.stop()
                chipAudio?.currentTime = 0
                
                spinAudio?.stop()
                spinAudio?.currentTime = 0
                
                winAudio?.stop()
                winAudio?.currentTime = 0
            }
            .onAppear() {
                initializeSounds()
            }
        }
    }
    
    func rouletteWheelView() -> some View {
        ZStack {
            Button {
                spinRoulette()
            } label: {
                ZStack {
                    Image("Roulette Wheel")
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: 300)
                    
                    Text("Play")
                        .foregroundColor(.black)
                        .font(.system(.largeTitle, design: .rounded)).bold()
                        .padding(10)
                }
            }
            .disabled(rouletteSpinning || (chipsPlaced == 0))
            
            Image("Roulette Ball")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 20)
                .offset(ballPosition)
        }
    }
    
    func rouletteBoardView() -> some View {
        ZStack (alignment: .topLeading) {
            Image("Roulette Board")
                .resizable()
                .scaledToFit()
                .frame(width: 600)
            
            VStack {
                HStack {
                    Button {
                        if (!oddBet) {
                            if gameState.money >= checkChip() {
                                oddBet.toggle()
                                oddChip = checkChip()
                                gameState.money -= oddChip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            oddBet.toggle()
                            gameState.money += oddChip
                            chipsPlaced -= 1
                        }
                    } label: {
                        ZStack {
                            Text("ODD")
                                .foregroundColor(.white)
                                .font(.system(.title3, design: .rounded)).bold()
                                .padding(7)
                                .overlay (
                                    Group {
                                        if oddBet {
                                            Image("Chip " + String(oddChip))
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 50, height: 30)
                                        }
                                    }
                                )
                        }
                    }
                    .offset(x: 75.0, y: 93.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!blackBet) {
                            if gameState.money >= checkChip() {
                                blackBet.toggle()
                                blackChip = checkChip()
                                gameState.money -= blackChip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            blackBet.toggle()
                            gameState.money += blackChip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("BLACK")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(7)
                            .overlay (
                                Group {
                                    if blackBet {
                                        Image("Chip " + String(blackChip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 101.0, y: 93.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!whiteBet) {
                            if gameState.money >= checkChip() {
                                whiteBet.toggle()
                                whiteChip = checkChip()
                                gameState.money -= whiteChip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            whiteBet.toggle()
                            gameState.money += whiteChip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("WHITE")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(7)
                            .overlay (
                                Group {
                                    if whiteBet {
                                        Image("Chip " + String(whiteChip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 118.0, y: 93.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!evenBet) {
                            if gameState.money >= checkChip() {
                                evenBet.toggle()
                                evenChip = checkChip()
                                gameState.money -= evenChip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            evenBet.toggle()
                            gameState.money += evenChip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("EVEN")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(7)
                            .overlay (
                                Group {
                                    if evenBet {
                                        Image("Chip " + String(evenChip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 142.0, y: 93.0)
                    .disabled(rouletteSpinning)
                }
                
                HStack {
                    Button {
                        if (!to2536Bet) {
                            if gameState.money >= checkChip() {
                                to2536Bet.toggle()
                                to2536Chip = checkChip()
                                gameState.money -= to2536Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            to2536Bet.toggle()
                            gameState.money += to2536Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("25 TO 36")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(5)
                            .overlay (
                                Group {
                                    if to2536Bet {
                                        Image("Chip " + String(to2536Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 62.0, y: 92.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!to1324Bet) {
                            if gameState.money >= checkChip() {
                                to1324Bet.toggle()
                                to1324Chip = checkChip()
                                gameState.money -= to1324Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            to1324Bet.toggle()
                            gameState.money += to1324Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("13 TO 24")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(5)
                            .overlay (
                                Group {
                                    if to1324Bet {
                                        Image("Chip " + String(to1324Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 99.0, y: 92.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!to0112Bet) {
                            if gameState.money >= checkChip() {
                                to0112Bet.toggle()
                                to0112Chip = checkChip()
                                gameState.money -= to0112Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            to0112Bet.toggle()
                            gameState.money += to0112Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("1 TO 12")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(5)
                            .overlay (
                                Group {
                                    if to0112Bet {
                                        Image("Chip " + String(to0112Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 143.0, y: 92.0)
                    .disabled(rouletteSpinning)
                }
                
                HStack {
                    Button {
                        if (!top2to1Bet) {
                            if gameState.money >= checkChip() {
                                top2to1Bet.toggle()
                                top2to1Chip = checkChip()
                                gameState.money -= top2to1Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            top2to1Bet.toggle()
                            gameState.money += top2to1Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("2 - 1")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(5)
                            .rotationEffect(.degrees(90))
                            .overlay (
                                Group {
                                    if top2to1Bet {
                                        Image("Chip " + String(top2to1Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 74.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[33]) {
                            if gameState.money >= checkChip() {
                                numberBet[33].toggle()
                                numberChip[33] = checkChip()
                                gameState.money -= numberChip[33]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[33].toggle()
                            gameState.money += numberChip[33]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("34")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[33] {
                                        Image("Chip " + String(numberChip[33]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 68.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[30]) {
                            if gameState.money >= checkChip() {
                                numberBet[30].toggle()
                                numberChip[30] = checkChip()
                                gameState.money -= numberChip[30]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[30].toggle()
                            gameState.money += numberChip[30]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("31")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[30] {
                                        Image("Chip " + String(numberChip[30]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 70.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[27]) {
                            if gameState.money >= checkChip() {
                                numberBet[27].toggle()
                                numberChip[27] = checkChip()
                                gameState.money -= numberChip[27]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[27].toggle()
                            gameState.money += numberChip[27]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("28")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[27] {
                                        Image("Chip " + String(numberChip[27]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 72.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[24]) {
                            if gameState.money >= checkChip() {
                                numberBet[24].toggle()
                                numberChip[24] = checkChip()
                                gameState.money -= numberChip[24]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[24].toggle()
                            gameState.money += numberChip[24]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("25")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[24] {
                                        Image("Chip " + String(numberChip[24]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 74.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[21]) {
                            if gameState.money >= checkChip() {
                                numberBet[21].toggle()
                                numberChip[21] = checkChip()
                                gameState.money -= numberChip[21]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[21].toggle()
                            gameState.money += numberChip[21]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("22")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[21] {
                                        Image("Chip " + String(numberChip[21]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 75.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[18]) {
                            if gameState.money >= checkChip() {
                                numberBet[18].toggle()
                                numberChip[18] = checkChip()
                                gameState.money -= numberChip[18]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[18].toggle()
                            gameState.money += numberChip[18]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("19")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[18] {
                                        Image("Chip " + String(numberChip[18]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 78.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[15]) {
                            if gameState.money >= checkChip() {
                                numberBet[15].toggle()
                                numberChip[15] = checkChip()
                                gameState.money -= numberChip[15]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[15].toggle()
                            gameState.money += numberChip[15]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("16")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[15] {
                                        Image("Chip " + String(numberChip[15]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 82.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[12]) {
                            if gameState.money >= checkChip() {
                                numberBet[12].toggle()
                                numberChip[12] = checkChip()
                                gameState.money -= numberChip[12]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[12].toggle()
                            gameState.money += numberChip[12]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("13")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[12] {
                                        Image("Chip " + String(numberChip[12]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 85.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[9]) {
                            if gameState.money >= checkChip() {
                                numberBet[9].toggle()
                                numberChip[9] = checkChip()
                                gameState.money -= numberChip[9]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[9].toggle()
                            gameState.money += numberChip[9]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("10")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[9] {
                                        Image("Chip " + String(numberChip[9]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 87.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[6]) {
                            if gameState.money >= checkChip() {
                                numberBet[6].toggle()
                                numberChip[6] = checkChip()
                                gameState.money -= numberChip[6]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[6].toggle()
                            gameState.money += numberChip[6]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("7")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[6] {
                                        Image("Chip " + String(numberChip[6]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 96.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[3]) {
                            if gameState.money >= checkChip() {
                                numberBet[3].toggle()
                                numberChip[3] = checkChip()
                                gameState.money -= numberChip[3]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[3].toggle()
                            gameState.money += numberChip[3]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("4")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[3] {
                                        Image("Chip " + String(numberChip[3]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 106.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[0]) {
                            if gameState.money >= checkChip() {
                                numberBet[0].toggle()
                                numberChip[0] = checkChip()
                                gameState.money -= numberChip[0]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[0].toggle()
                            gameState.money += numberChip[0]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("1")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[0] {
                                        Image("Chip " + String(numberChip[0]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 118.0, y: 95.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!s0Bet) {
                            if gameState.money >= checkChip() {
                                s0Bet.toggle()
                                s0Chip = checkChip()
                                gameState.money -= s0Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            s0Bet.toggle()
                            gameState.money += s0Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("0")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(2)
                            .rotationEffect(.degrees(90))
                            .overlay (
                                Group {
                                    if s0Bet {
                                        Image("Chip " + String(s0Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 125.0, y: 106.0)
                    .disabled(rouletteSpinning)
                }
                
                HStack {
                    Button {
                        if (!mid2to1Bet) {
                            if gameState.money >= checkChip() {
                                mid2to1Bet.toggle()
                                mid2to1Chip = checkChip()
                                gameState.money -= mid2to1Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            mid2to1Bet.toggle()
                            gameState.money += mid2to1Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("2 - 1")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(5)
                            .rotationEffect(.degrees(90))
                            .overlay (
                                Group {
                                    if mid2to1Bet {
                                        Image("Chip " + String(mid2to1Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 64.0, y: 102.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[34]) {
                            if gameState.money >= checkChip() {
                                numberBet[34].toggle()
                                numberChip[34] = checkChip()
                                gameState.money -= numberChip[34]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[34].toggle()
                            gameState.money += numberChip[34]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("35")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[34] {
                                        Image("Chip " + String(numberChip[34]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 58.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[31]) {
                            if gameState.money >= checkChip() {
                                numberBet[31].toggle()
                                numberChip[31] = checkChip()
                                gameState.money -= numberChip[31]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[31].toggle()
                            gameState.money += numberChip[31]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("32")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[31] {
                                        Image("Chip " + String(numberChip[31]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 59.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[28]) {
                            if gameState.money >= checkChip() {
                                numberBet[28].toggle()
                                numberChip[28] = checkChip()
                                gameState.money -= numberChip[28]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[28].toggle()
                            gameState.money += numberChip[28]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("29")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[28] {
                                        Image("Chip " + String(numberChip[28]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 61.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[25]) {
                            if gameState.money >= checkChip() {
                                numberBet[25].toggle()
                                numberChip[25] = checkChip()
                                gameState.money -= numberChip[25]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[25].toggle()
                            gameState.money += numberChip[25]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("26")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[25] {
                                        Image("Chip " + String(numberChip[25]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 63.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[22]) {
                            if gameState.money >= checkChip() {
                                numberBet[22].toggle()
                                numberChip[22] = checkChip()
                                gameState.money -= numberChip[22]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[22].toggle()
                            gameState.money += numberChip[22]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("23")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[22] {
                                        Image("Chip " + String(numberChip[22]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 64.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[19]) {
                            if gameState.money >= checkChip() {
                                numberBet[19].toggle()
                                numberChip[19] = checkChip()
                                gameState.money -= numberChip[19]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[19].toggle()
                            gameState.money += numberChip[19]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("20")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[19] {
                                        Image("Chip " + String(numberChip[19]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 66.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[16]) {
                            if gameState.money >= checkChip() {
                                numberBet[16].toggle()
                                numberChip[16] = checkChip()
                                gameState.money -= numberChip[16]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[16].toggle()
                            gameState.money += numberChip[16]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("17")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[16] {
                                        Image("Chip " + String(numberChip[16]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 68.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[13]) {
                            if gameState.money >= checkChip() {
                                numberBet[13].toggle()
                                numberChip[13] = checkChip()
                                gameState.money -= numberChip[13]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[13].toggle()
                            gameState.money += numberChip[13]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("14")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[13] {
                                        Image("Chip " + String(numberChip[13]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 73.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[10]) {
                            if gameState.money >= checkChip() {
                                numberBet[10].toggle()
                                numberChip[10] = checkChip()
                                gameState.money -= numberChip[10]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[10].toggle()
                            gameState.money += numberChip[10]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("11")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[10] {
                                        Image("Chip " + String(numberChip[10]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 76.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[7]) {
                            if gameState.money >= checkChip() {
                                numberBet[7].toggle()
                                numberChip[7] = checkChip()
                                gameState.money -= numberChip[7]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[7].toggle()
                            gameState.money += numberChip[7]
                            chipsPlaced -= 1
                        }
                    } label: {
                        ZStack {
                            Text("8")
                                .foregroundColor(.white)
                                .font(.system(.body, design: .rounded)).bold()
                                .padding(2)
                                .overlay (
                                    Group {
                                        if numberBet[7] {
                                            Image("Chip " + String(numberChip[7]))
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 50, height: 30)
                                        }
                                    }
                                )
                        }
                    }
                    .offset(x: 84.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[4]) {
                            if gameState.money >= checkChip() {
                                numberBet[4].toggle()
                                numberChip[4] = checkChip()
                                gameState.money -= numberChip[4]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[4].toggle()
                            gameState.money += numberChip[4]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("5")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[4] {
                                        Image("Chip " + String(numberChip[4]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 95.0, y: 101.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[1]) {
                            if gameState.money >= checkChip() {
                                numberBet[1].toggle()
                                numberChip[1] = checkChip()
                                gameState.money -= numberChip[1]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[1].toggle()
                            gameState.money += numberChip[1]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("2")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[1] {
                                        Image("Chip " + String(numberChip[1]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 106.0, y: 101.0)
                    .disabled(rouletteSpinning)
                }
                
                HStack {
                    Button {
                        if (!bot2to1Bet) {
                            if gameState.money >= checkChip() {
                                bot2to1Bet.toggle()
                                bot2to1Chip = checkChip()
                                gameState.money -= bot2to1Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            bot2to1Bet.toggle()
                            gameState.money += bot2to1Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("2 - 1")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(5)
                            .rotationEffect(.degrees(90))
                            .overlay (
                                Group {
                                    if bot2to1Bet {
                                        Image("Chip " + String(bot2to1Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 81.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[35]) {
                            if gameState.money >= checkChip() {
                                numberBet[35].toggle()
                                numberChip[35] = checkChip()
                                gameState.money -= numberChip[35]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[35].toggle()
                            gameState.money += numberChip[35]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("36")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[35] {
                                        Image("Chip " + String(numberChip[35]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 75.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[32]) {
                            if gameState.money >= checkChip() {
                                numberBet[32].toggle()
                                numberChip[32] = checkChip()
                                gameState.money -= numberChip[32]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[32].toggle()
                            gameState.money += numberChip[32]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("33")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[32] {
                                        Image("Chip " + String(numberChip[32]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 77.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[29]) {
                            if gameState.money >= checkChip() {
                                numberBet[29].toggle()
                                numberChip[29] = checkChip()
                                gameState.money -= numberChip[29]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[29].toggle()
                            gameState.money += numberChip[29]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("30")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[29] {
                                        Image("Chip " + String(numberChip[29]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 78.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[26]) {
                            if gameState.money >= checkChip() {
                                numberBet[26].toggle()
                                numberChip[26] = checkChip()
                                gameState.money -= numberChip[26]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[26].toggle()
                            gameState.money += numberChip[26]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("27")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[26] {
                                        Image("Chip " + String(numberChip[26]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 80.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[23]) {
                            if gameState.money >= checkChip() {
                                numberBet[23].toggle()
                                numberChip[23] = checkChip()
                                gameState.money -= numberChip[23]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[23].toggle()
                            gameState.money += numberChip[23]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("24")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[23] {
                                        Image("Chip " + String(numberChip[23]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 81.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[20]) {
                            if gameState.money >= checkChip() {
                                numberBet[20].toggle()
                                numberChip[20] = checkChip()
                                gameState.money -= numberChip[20]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[20].toggle()
                            gameState.money += numberChip[20]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("21")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[20] {
                                        Image("Chip " + String(numberChip[20]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 84.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[17]) {
                            if gameState.money >= checkChip() {
                                numberBet[17].toggle()
                                numberChip[17] = checkChip()
                                gameState.money -= numberChip[17]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[17].toggle()
                            gameState.money += numberChip[17]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("18")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[17] {
                                        Image("Chip " + String(numberChip[17]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 88.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[14]) {
                            if gameState.money >= checkChip() {
                                numberBet[14].toggle()
                                numberChip[14] = checkChip()
                                gameState.money -= numberChip[14]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[14].toggle()
                            gameState.money += numberChip[14]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("15")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[14] {
                                        Image("Chip " + String(numberChip[14]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 91.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[11]) {
                            if gameState.money >= checkChip() {
                                numberBet[11].toggle()
                                numberChip[11] = checkChip()
                                gameState.money -= numberChip[11]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[11].toggle()
                            gameState.money += numberChip[11]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("12")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[11] {
                                        Image("Chip " + String(numberChip[11]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 94.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[8]) {
                            if gameState.money >= checkChip() {
                                numberBet[8].toggle()
                                numberChip[8] = checkChip()
                                gameState.money -= numberChip[8]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[8].toggle()
                            gameState.money += numberChip[8]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("9")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[8] {
                                        Image("Chip " + String(numberChip[8]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 101.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[5]) {
                            if gameState.money >= checkChip() {
                                numberBet[5].toggle()
                                numberChip[5] = checkChip()
                                gameState.money -= numberChip[5]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[5].toggle()
                            gameState.money += numberChip[5]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("6")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[5] {
                                        Image("Chip " + String(numberChip[5]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 112.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!numberBet[2]) {
                            if gameState.money >= checkChip() {
                                numberBet[2].toggle()
                                numberChip[2] = checkChip()
                                gameState.money -= numberChip[2]
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            numberBet[2].toggle()
                            gameState.money += numberChip[2]
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("3")
                            .foregroundColor(.white)
                            .font(.system(.body, design: .rounded)).bold()
                            .padding(2)
                            .overlay (
                                Group {
                                    if numberBet[2] {
                                        Image("Chip " + String(numberChip[2]))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 123.0, y: 107.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!s00Bet) {
                            if gameState.money >= checkChip() {
                                s00Bet.toggle()
                                s00Chip = checkChip()
                                gameState.money -= s00Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            s00Bet.toggle()
                            gameState.money += s00Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("00")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(2)
                            .rotationEffect(.degrees(90))
                            .overlay (
                                Group {
                                    if s00Bet {
                                        Image("Chip " + String(s00Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 123.0, y: 95.0)
                    .disabled(rouletteSpinning)
                }
                
                HStack {
                    Button {
                        if (!to1936Bet) {
                            if gameState.money >= checkChip() {
                                to1936Bet.toggle()
                                to1936Chip = checkChip()
                                gameState.money -= to1936Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            to1936Bet.toggle()
                            gameState.money += to1936Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("19 TO 36")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(5)
                            .overlay (
                                Group {
                                    if to1936Bet {
                                        Image("Chip " + String(to1936Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 50.0, y: 110.0)
                    .disabled(rouletteSpinning)
                    
                    Button {
                        if (!to0118Bet) {
                            if gameState.money >= checkChip() {
                                to0118Bet.toggle()
                                to0118Chip = checkChip()
                                gameState.money -= to0118Chip
                                chipsPlaced += 1
                                playChipSound()
                            }
                        } else {
                            to0118Bet.toggle()
                            gameState.money += to0118Chip
                            chipsPlaced -= 1
                        }
                    } label: {
                        Text("1 TO 18")
                            .foregroundColor(.white)
                            .font(.system(.title3, design: .rounded)).bold()
                            .padding(5)
                            .overlay (
                                Group {
                                    if to0118Bet {
                                        Image("Chip " + String(to0118Chip))
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 30)
                                    }
                                }
                            )
                    }
                    .offset(x: 157.0, y: 110.0)
                    .disabled(rouletteSpinning)
                }
            }
        }
    }
}



#Preview {
    RouletteGameView()
        .environmentObject(GameState())
}
