import SwiftUI

struct GameMenuView: View {
    @Binding var username: String
    
    let games = ["Slots", "Blackjack", "Roulette", "Baccarat", "Shark Cashout", "Blackjack AR"]
    let gameViews: [String: AnyView] = [
        "Slots": AnyView(SlotsGameView()),
        "Blackjack": AnyView(BlackjackGameView()),
        "Roulette": AnyView(RouletteGameView()),
        "Baccarat": AnyView(BaccaratGameView()),
        "Shark Cashout": AnyView(SharkCashoutView()),
        "Blackjack AR": AnyView(BlackjackARGameView())
    ]
    let columns = [
        GridItem(.adaptive(minimum: 250))
    ]
    let Maroon = Color(red: 0.48, green: 0.08, blue: 0.08)
    
    var body: some View {
        NavigationStack {                    
            VStack {
                Text("Welcome back, \(username)!")
                    .font(.system(.title, design: .rounded)).bold()
                    .foregroundColor(.white)
                    .padding()
                
                ScrollView {
                    LazyVGrid(columns: columns) {
                        ForEach(games, id: \.self) {game in
                            NavigationLink(destination: gameViews[game]) {
                                VStack {
                                    Image(game)
                                        .resizable()
                                        .scaledToFit()
                                        .cornerRadius(25)
                                        .padding(.horizontal)
                                    Text("\(game)")
                                        .font(.system(.title2, design: .rounded)).bold()
                                        .foregroundColor(.orange)
                                        .padding(.bottom, 40)
                                }
                            }
                        }
                    }
                }
            }
            .background(
                Image("Cloth")
                    .resizable()
                    .scaledToFill()
            )
        }
        .navigationBarBackButtonHidden(true)
    }
}

#Preview {
    GameMenuView(username: .constant("Carlos"))
}
