import SwiftUI

class GameState: ObservableObject {
    @Published var money: Int = 1000
}
