import SwiftUI
import AVFoundation

struct ContentView: View {
    @EnvironmentObject var gameState: GameState
    
    @State private var audioPlayer: AVAudioPlayer?
    
    let Maroon = Color(red: 0.48, green: 0.08, blue: 0.08)
    
    func startBGM() {
        guard let url = Bundle.main.url(forResource: "Blackjack BGM", withExtension: "mp3") else {
            return
        }
        
        audioPlayer = try? AVAudioPlayer(contentsOf: url)
        audioPlayer?.numberOfLoops = -1
        audioPlayer?.play()
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("Cloth")
                    .resizable()
                    .scaledToFill()
                
                VStack {
                    Spacer()
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight:300)
                    
                    Spacer()
                    NavigationLink(destination: LoginView()) {
                        Text("Play")
                            .font(.system(.largeTitle, design: .rounded)).bold()
                            .padding(.horizontal, 30)
                            .padding(.vertical, 10)
                            .foregroundColor(Maroon)
                            .background(Color.orange)
                            .cornerRadius(15)
                    }
                    Spacer()
                }
            }
        }
        .onAppear {
            startBGM()
        }
    }
}
